//Ford Tang
//46564602
//ICS 45C
//Project 3

#include "Command.hpp"

int main()
{
    Command Test;
    Test.getCommand();

    return 0;
}

