//Ford Tang
//46564602
//ICS 45C
//Project 2

#ifndef _calculate
#define _calculate
#include "graded_artifacts.h"
#include "student.h"

double calculateTotal(double student_score, double total, double weight);

void calculateGrades(unsigned int number_of_students, unsigned int set, graded_artifacts *grades, student **students);

#endif
