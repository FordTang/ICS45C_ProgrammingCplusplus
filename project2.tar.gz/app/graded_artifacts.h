//Ford Tang
//46564602
//ICS 45C
//Project 2

#ifndef _graded_artifacts
#define _graded_artifacts

struct graded_artifacts
{
    unsigned int number;
    unsigned int* total_points;
    unsigned int* weight;
    unsigned int cutpoint_sets;
    double* grade_a;
    double* grade_b;
    double* grade_c;
    double* grade_d;
};

#endif
