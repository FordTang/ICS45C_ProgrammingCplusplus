//Ford Tang
//46564602
//ICS 45C
//Project 2

#ifndef _printout
#define _printout
#include <iostream>
#include "student.h"
#include "graded_artifacts.h"


void printTotalScores(unsigned int number_of_students, graded_artifacts *grades, student **students);

void printCutpointSets(unsigned int number_of_students, unsigned int set, graded_artifacts *grades, student **students);

#endif
