//Ford Tang
//46564602
//ICS 45C
//Project 2

#ifndef _cleanup
#define _cleanup
#include "graded_artifacts.h"
#include "student.h"

void cleanup(graded_artifacts *grades);

void cleanup(student *student);

void cleanup(unsigned int number_of_students, student **students);

#endif
