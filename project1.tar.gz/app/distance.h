//Ford Tang
//46564602
//ICS 45C

#ifndef _distance
#define _distance
#include <cmath>

double calculate(double lat1, double lon1, double lat2, double lon2);

#endif
