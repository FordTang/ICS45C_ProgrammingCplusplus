//Ford Tang
//46564602
//ICS 45C

#ifndef _getinput
#define _getinput
#include <iostream>
#include <string>
#include "location.h"

location getInput();
//gets users input  and returns a location object

#endif
