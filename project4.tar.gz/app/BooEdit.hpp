// BooEdit.hpp
//
// ICS 45C Fall 2014
// Project #4: People Just Love to Play with Words
//
// Entry-point function for running BooEdit
//
// DO NOT MODIFY THIS FILE

#ifndef BOOEDIT_HPP
#define BOOEDIT_HPP



void runBooEdit();



#endif // BOOEDIT_HPP

